#pragma once
#include <limits>

namespace sensors::error
{
    constexpr int code = std::numeric_limits<int>::min();
}
